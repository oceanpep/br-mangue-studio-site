# Test dataset — Maranhão Island, 2025

This package contains geospatial inputs prepared for testing BR-MANGUE Studio. It is a regional starter example, not the only data source the model can use.

## Files

- `dados/cobertura_terra_2025.tif` — single-band 2025 land-cover and land-use map (band 41 of the MapBiomas Brazil Collection 11 series).
- `dados/DEM_30m.tif` — 30 m digital elevation model.
- `legenda/codigo_legenda_mapbiomas_colecao_11.csv` — official legend file with pixel code, class names in Portuguese and English, and color.

Both GeoTIFFs use the same aligned grid: 2,142 columns × 2,122 rows, 30 m resolution, SIRGAS 2000 / UTM zone 23S (EPSG:31983). DEM NoData is -9999; the land-cover raster uses 0 for NoData.

## Open in BR-MANGUE Studio

1. Download and extract the package.
2. In BR-MANGUE Studio, choose `cobertura_terra_2025.tif` as the land-cover input and `DEM_30m.tif` as the elevation input.
3. Use the CSV to identify the integer codes in the raster cells, then map those classes to model roles in the scenario settings.
4. Choose the years, parameters, and processing engine, then run the simulation.

For reference, the pilot test mapped MapBiomas code 5 to mangrove; 33 to water; 6, 11, 12, 23, 32, 49, and 50 to natural accommodation candidates; 14, 15, 18, 19, 20, 21, 35, 36, 39, 40, 41, 46, 47, 48, and 62 to managed land uses; and 24, 25, and 30 to explicit restrictions. Codes without a specific mapping used the anthropized class. This records the pilot setup; it is not a universal ecological classification. Adapt the mapping to your research question and data.

## Limits of this example

The raster window was used in software tests and does not include a mask that follows the exact boundary of Maranhão Island. It therefore contains valid cells outside the island's strict boundary. Use this package to try data loading, grid alignment, reprojection, and model execution. Its results are not a validated ecological projection for the island.

BR-MANGUE Studio does not require MapBiomas or ANADEM. For another study area, use compatible land-cover data and a DEM appropriate to your research.

See `FONTES_E_LICENCAS.md` for source links, citations, licenses, and the transformations applied to these files.
