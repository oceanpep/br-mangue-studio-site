# Test dataset — Maranhão Island, 2025

This package provides inputs for testing BR-MANGUE Studio data loading, alignment, masking, and simulation. It is a regional example; the model also accepts data from other sources and study areas.

## Files

- `dados/cobertura_terra_2025.tif` — single-band categorical land-cover raster for 2025.
- `dados/DEM_30m.tif` — digital elevation model with 30 m resolution.
- `dados/mascara_area_estudo.tif` — optional binary study-area mask; value 1 inside and 0/NoData outside.
- `limites/area_estudo_ilha_maranhao_ibge_2024.gpkg` — the four source municipal boundaries and their union, in the raster coordinate system.
- `legenda/codigo_legenda_mapbiomas_colecao_11.csv` — codes, names, and colors for the land-cover classes.

All three GeoTIFFs use the same grid: 2,142 columns × 2,122 rows, 30 m resolution, SIRGAS 2000 / UTM zone 23S (EPSG:31983). The DEM uses -9999 as NoData; land cover uses 0. The mask is aligned to the same grid and uses 0 as NoData. With the mask, the loader finds 1,067,251 valid cells; without it, the full raster window contains 2,303,260 valid cells.

The mask represents the union of the 2024 IBGE municipal boundaries for São Luís (2111300), São José de Ribamar (2111201), Paço do Lumiar (2107506), and Raposa (2109452). It retains water inside those polygons and excludes cells outside their union. This is an administrative regional delineation, not an independently surveyed coastline. The GeoPackage contains the four municipal features in layer `municipios_ilha` and the dissolved union used to create the mask in layer `area_estudo`.

## Open in BR-MANGUE Studio

1. Download and extract the package.
2. In the input tab, select `cobertura_terra_2025.tif` as land cover and `DEM_30m.tif` as elevation.
3. In the optional **Study-area mask** field, select `mascara_area_estudo.tif` to restrict the simulation to the union of the four municipalities. If the field is empty, the model uses all valid cells in the rectangular raster grid.
4. Use the CSV to inspect the integer class codes and map them to model roles.
5. Choose the years, parameters, and processing engine, then run the model.

For reference, the pilot test mapped code 5 to mangrove; 33 to water; 6, 11, 12, 23, 32, 49, and 50 to natural accommodation candidates; 14, 15, 18, 19, 20, 21, 35, 36, 39, 40, 41, 46, 47, 48, and 62 to managed land uses; and 24, 25, and 30 to explicit restrictions. This records the pilot setup, not a universal ecological classification. Adapt the mapping to your research question and data.

## Limits of this example

When selected, the mask excludes cells outside the administrative union. It retains internal water and small islands included within the municipal boundaries. Use this package to test data loading, alignment, reprojection, and model execution; the results are not a validated ecological projection for Maranhão Island.

BR-MANGUE Studio does not require MapBiomas or ANADEM. For another study area, use compatible land-cover data, a DEM, and, if needed, an aligned binary mask.

See `FONTES_E_LICENCAS.md` for sources, citations, licenses, and the transformations applied to these files.
