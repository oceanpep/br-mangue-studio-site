# Fontes e licenças / Sources and licenses

## Português

### Limites municipais e máscara da área de estudo

Fonte: Instituto Brasileiro de Geografia e Estatística (IBGE), Malha Municipal 2024 do Maranhão. A página oficial informa que os arquivos disponibilizados são públicos: https://geoftp.ibge.gov.br/organizacao_do_territorio/malhas_territoriais/malhas_municipais/municipio_2024/UFs/MA/. Arquivo de origem: `MA_Municipios_2024.zip`; SHA-256: `8016c288348a61a824d4b6454e5b0f292e1692f2795faa6bd96f151efdf55bfa`.

Alterações: foram selecionados os municípios São Luís (2111300), São José de Ribamar (2111201), Paço do Lumiar (2107506) e Raposa (2109452), reprojetados para EPSG:31983 e dissolvidos para formar a área administrativa de teste. O GeoPackage mantém os quatro polígonos de origem e a união dissolvida. A máscara foi rasterizada na grade da cobertura da terra por regra do centro da célula: 1 dentro da união e 0/NoData fora. Águas internas e ilhas incluídas nos limites municipais permanecem na máscara. Portanto, trata-se da união dos limites municipais que compõem a Ilha do Maranhão, não de uma linha costeira independente levantada em campo.

### Cobertura e uso da terra e legenda

Fonte: Projeto MapBiomas Brasil, Série Anual de Mapas de Cobertura e Uso da Terra, Coleção 11 (30 m), ano 2025. O portal informa que os dados são públicos, abertos e gratuitos sob CC BY 4.0 e pede referência à fonte.

Citação sugerida: Projeto MapBiomas — Coleção 11 da Série Anual de Mapas de Cobertura e Uso da Terra do Brasil, acessada em 2 out. 2026: https://brasil.mapbiomas.org/iniciativas-e-produtos/cobertura-e-uso-da-terra/cobertura-30m/cobertura/

A legenda CSV incluída foi baixada do portal oficial em 2 out. 2026: https://brasil.mapbiomas.org/wp-content/uploads/sites/3/2026/08/legend_code_mapbiomas_brazil_collection_11.csv. A lista oficial de códigos e descrições também está em https://brasil.mapbiomas.org/downloads/codigos-de-legenda/.

Alterações neste pacote: extração da banda 41 (ano 2025) da série multibanda fornecida localmente e reprojeção para EPSG:31983 com vizinho mais próximo, apropriado para categorias. O CSV de legenda foi incluído sem alterações.

### Modelo digital de elevação

Fonte: Agência Nacional de Águas e Saneamento Básico (ANADEM), distribuído pelo OpenTopography sob CC BY 4.0. Metadados e licença: https://portal.opentopography.org/datasetMetadata?otCollectionID=OT.082025.4674.1

Citação do conjunto: Agência Nacional de Águas e Saneamento Básico. (2025). ANADEM: A Digital Terrain Model for South America. Distributed by OpenTopography. https://doi.org/10.5069/G9736P4G. Acessado em 2 out. 2026.

Referência do artigo: Laipelt, L. et al. (2024). ANADEM: A Digital Terrain Model for South America. Remote Sensing, 16(13), 2321. https://doi.org/10.3390/rs16132321.

Alterações neste pacote: reprojeção do arquivo de elevação para EPSG:31983 com interpolação bilinear para coincidir com a grade de cobertura da terra.

### Aviso

MapBiomas e ANADEM são produtos de terceiros. Este conjunto é uma compilação independente para teste e não implica patrocínio ou endosso pelos provedores. As licenças dos dados originais continuam aplicáveis; preserve as atribuições acima ao compartilhar os arquivos.

## English

### Municipal boundaries and study-area mask

Source: Brazilian Institute of Geography and Statistics (IBGE), 2024 Municipal Mesh for Maranhão. The official directory states that its files are public: https://geoftp.ibge.gov.br/organizacao_do_territorio/malhas_territoriais/malhas_municipais/municipio_2024/UFs/MA/. Source archive: `MA_Municipios_2024.zip`; SHA-256: `8016c288348a61a824d4b6454e5b0f292e1692f2795faa6bd96f151efdf55bfa`.

Changes: São Luís (2111300), São José de Ribamar (2111201), Paço do Lumiar (2107506), and Raposa (2109452) were selected, reprojected to EPSG:31983, and dissolved to create the administrative test area. The GeoPackage retains the four source polygons and the dissolved union. The mask was rasterized on the land-cover grid using the pixel-center rule: 1 inside the union and 0/NoData outside. Internal water and islands included within the municipal boundaries remain in the mask. This is the union of the municipal boundaries that make up Maranhão Island, not an independently surveyed coastline.

### Land cover and legend

Source: MapBiomas Brazil, Annual Land Use and Land Cover Mapping, Collection 11 (30 m), year 2025. The official portal states that the data are public, open, free to use under CC BY 4.0, and require source attribution.

Suggested citation: MapBiomas Project — Collection 11 of the Annual Land Use and Land Cover Mapping of Brazil, accessed 2 Oct 2026: https://brasil.mapbiomas.org/iniciativas-e-produtos/cobertura-e-uso-da-terra/cobertura-30m/cobertura/

The included legend CSV was downloaded from the official portal on 2 Oct 2026: https://brasil.mapbiomas.org/wp-content/uploads/sites/3/2026/08/legend_code_mapbiomas_brazil_collection_11.csv. The official legend downloads page is https://brasil.mapbiomas.org/downloads/codigos-de-legenda/.

Changes in this package: band 41 (year 2025) was extracted from the locally supplied multiband series and reprojected to EPSG:31983 using nearest-neighbour resampling, appropriate for categorical data. The legend CSV is included unchanged.

### Digital elevation model

Source: Agência Nacional de Águas e Saneamento Básico (ANADEM), distributed by OpenTopography under CC BY 4.0. Metadata and license: https://portal.opentopography.org/datasetMetadata?otCollectionID=OT.082025.4674.1

Dataset citation: Agência Nacional de Águas e Saneamento Básico. (2025). ANADEM: A Digital Terrain Model for South America. Distributed by OpenTopography. https://doi.org/10.5069/G9736P4G. Accessed 2 Oct 2026.

Paper reference: Laipelt, L. et al. (2024). ANADEM: A Digital Terrain Model for South America. Remote Sensing, 16(13), 2321. https://doi.org/10.3390/rs16132321.

Changes in this package: the elevation file was reprojected to EPSG:31983 with bilinear interpolation to align with the land-cover grid.

### Notice

MapBiomas and ANADEM are third-party products. This is an independent test-data bundle and does not imply sponsorship or endorsement by the data providers. The original data licenses remain in force; preserve the attributions above when sharing the files.
