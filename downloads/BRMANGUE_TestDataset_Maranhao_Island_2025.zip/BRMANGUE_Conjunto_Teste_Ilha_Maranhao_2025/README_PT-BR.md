# Conjunto de dados de teste — Ilha do Maranhão, 2025

Este pacote contém entradas geoespaciais preparadas para testar o BR-MANGUE Studio. É um exemplo regional para começar a usar o programa; não é a única fonte de dados aceita pelo modelo.

## Arquivos

- `dados/cobertura_terra_2025.tif` — mapa categórico de cobertura e uso da terra de 2025 (banda 41 da série MapBiomas Brasil, Coleção 11), em uma única banda.
- `dados/DEM_30m.tif` — modelo digital de elevação de 30 m.
- `legenda/codigo_legenda_mapbiomas_colecao_11.csv` — arquivo oficial com código do pixel, nome da classe em português e inglês e cor.

Os dois GeoTIFFs estão alinhados na mesma grade: 2.142 colunas × 2.122 linhas, resolução de 30 m e sistema de coordenadas SIRGAS 2000 / UTM 23S (EPSG:31983). O valor NoData do DEM é -9999; o do mapa de cobertura é 0.

## Abrir no BR-MANGUE Studio

1. Baixe e extraia o pacote.
2. No BR-MANGUE Studio, selecione `cobertura_terra_2025.tif` como entrada de cobertura da terra e `DEM_30m.tif` como elevação.
3. Consulte o CSV para identificar o significado dos códigos inteiros nas células e associe as classes aos papéis do modelo na configuração do cenário.
4. Escolha os anos, parâmetros e mecanismo de processamento e execute a simulação.

Como exemplo de configuração usado no teste piloto, o código MapBiomas 5 foi associado a mangue; 33 a água; 6, 11, 12, 23, 32, 49 e 50 a classes de acomodação natural candidatas; 14, 15, 18, 19, 20, 21, 35, 36, 39, 40, 41, 46, 47, 48 e 62 a usos manejados; e 24, 25 e 30 a restrições explícitas. Códigos sem associação específica seguiram a classe antropizada. Essa associação registra o teste do pacote; não é uma classificação ecológica universal. Ajuste o mapeamento à sua pergunta de pesquisa e aos seus dados.

## Limites do exemplo

O recorte foi usado em testes do programa e não inclui uma máscara que acompanhe exatamente o limite da Ilha do Maranhão. Assim, a grade contém células válidas fora do limite estrito da ilha. Use o conjunto para testar leitura, alinhamento, reprojeção e execução do software. Os resultados não são uma projeção ecológica validada para a ilha.

O BR-MANGUE Studio não exige MapBiomas nem ANADEM: para outras áreas, use dados de cobertura da terra e DEM compatíveis com o seu estudo.

Consulte `FONTES_E_LICENCAS.md` para as fontes, citações, licenças e descrição das alterações feitas nos arquivos.
