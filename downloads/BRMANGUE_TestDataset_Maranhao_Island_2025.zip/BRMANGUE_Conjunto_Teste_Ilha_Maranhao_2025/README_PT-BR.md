# Conjunto de teste — Ilha do Maranhão, 2025

Este pacote reúne dados para testar a leitura, o alinhamento, a máscara e a execução do BR-MANGUE Studio. É um exemplo regional; o modelo também aceita dados de outras fontes e áreas.

## Arquivos

- `dados/cobertura_terra_2025.tif` — raster categórico de cobertura e uso da terra de 2025, uma banda.
- `dados/DEM_30m.tif` — modelo digital de elevação com resolução de 30 m.
- `dados/mascara_area_estudo.tif` — máscara binária opcional da área de estudo; valor 1 dentro e 0/NoData fora.
- `limites/area_estudo_ilha_maranhao_ibge_2024.gpkg` — quatro limites municipais de origem e sua união, no sistema de coordenadas dos rasters.
- `legenda/codigo_legenda_mapbiomas_colecao_11.csv` — códigos, nomes e cores das classes do raster de cobertura.

Os três GeoTIFFs usam a mesma grade: 2.142 colunas × 2.122 linhas, resolução de 30 m e SIRGAS 2000 / UTM 23S (EPSG:31983). O DEM usa -9999 como NoData; cobertura usa 0. A máscara foi alinhada à mesma grade e usa 0 como NoData. Com ela, o carregador identifica 1.067.251 células válidas; sem máscara, identifica 2.303.260 na janela raster completa.

A máscara representa a união dos limites municipais de São Luís (2111300), São José de Ribamar (2111201), Paço do Lumiar (2107506) e Raposa (2109452) da Malha Municipal 2024 do IBGE. Ela mantém águas internas aos polígonos e exclui células externas à união. É uma delimitação administrativa regional, não um levantamento independente da linha costeira. O GeoPackage contém as quatro feições municipais na camada `municipios_ilha` e a união usada para gerar a máscara na camada `area_estudo`.

## Abrir no BR-MANGUE Studio

1. Baixe e extraia o pacote.
2. Na aba de entradas, selecione `cobertura_terra_2025.tif` como cobertura da terra e `DEM_30m.tif` como elevação.
3. No campo opcional **Study-area mask / Máscara da área de estudo**, selecione `mascara_area_estudo.tif` para restringir a simulação à união dos quatro municípios. Se deixar o campo vazio, o programa usará todas as células válidas da grade retangular.
4. Use o CSV para conferir os códigos inteiros das classes e associá-los aos papéis do modelo.
5. Escolha anos, parâmetros e mecanismo de processamento e execute.

Como referência, no teste piloto o código 5 foi associado a mangue; 33 a água; 6, 11, 12, 23, 32, 49 e 50 a classes naturais candidatas; 14, 15, 18, 19, 20, 21, 35, 36, 39, 40, 41, 46, 47, 48 e 62 a usos manejados; e 24, 25 e 30 a restrições explícitas. Essa associação registra a configuração do piloto, não uma classificação ecológica universal. Ajuste os papéis à sua pergunta e aos seus dados.

## Limites do exemplo

Com a máscara selecionada, as células fora da união administrativa são excluídas. A máscara preserva águas internas e pequenas ilhas contidas nos limites municipais. Use o pacote para testar carregamento, alinhamento, reprojeção e execução; os resultados não constituem uma projeção ecológica validada para a Ilha do Maranhão.

O BR-MANGUE Studio não exige MapBiomas ou ANADEM. Para outra área, use dados compatíveis de cobertura da terra, DEM e, se necessário, uma máscara binária alinhada.

Consulte `FONTES_E_LICENCAS.md` para fontes, citações, licenças e descrição das transformações.
