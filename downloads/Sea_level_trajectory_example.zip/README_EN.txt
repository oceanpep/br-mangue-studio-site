# Sea-level trajectory CSV

This file contains SYNTHETIC example values. Replace every example level before research use.

1. Obtain regional cumulative sea-level projections from https://sealevel.nasa.gov/data_tools/17 or https://doi.org/10.5281/zenodo.6382554 . Earth Engine users can consult https://developers.google.com/earth-engine/datasets/catalog/IPCC_AR6_SLP .
2. Choose one scenario, percentile, and location or documented regional summary. Keep all values relative to the same reference period. Source downloads may need reformatting.
3. Open the example in Excel/LibreOffice Calc. Remove the optional first comment line beginning with #. Keep exact headers year and sea_level_mm. Replace years and cumulative levels, in millimetres. Convert metres × 1000 or centimetres × 10. Do not enter annual rates here.
4. Save as UTF-8 CSV. Use commas with decimal points, or semicolons with decimal points/commas. No thousands separators. Use at least two distinct whole years, sorted in increasing order, covering the full simulation interval.
5. In Simulation, select Year-based trajectory (CSV), choose the file, and inspect Preview curve. For a 2025–2100 run, decadal samples from 2020 to 2100 suffice.

The model interpolates intermediate years and subtracts the initial-year level. It rejects years outside the file range. The input baseline does not set the DEM's vertical reference or the initial tidal height.

Keep source, region, scenario, percentile, units and reference period in a separate source note. Each run exports sea_level_forcing.csv, the actual annual forcing used. An observed annual trend can instead be entered in Constant rate.

Guide: https://oceanpep.github.io/br-mangue-studio-site/sea-level-trajectories.html
